<?php include "inc/header.php"; ?>
<?php include "db.php"; 

$sql = "SELECT * FROM cars";
$result = $conn->query($sql);


?>

    <!-- PRE LOADER -->
    <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="#" class="navbar-brand">Car Dealer Website</a>
               </div>

    <!-- MENU LINKS -->
    <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-nav-first">
                    <li><a href="home.php">Home</a></li>
                    <li class="active"><a href="cars.php">Cars</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Admin<span class="caret"></span></a>
                        
                        <ul class="dropdown-menu">
                            <li><a href="add_car.php">Add Cars</a></li>
                            <li><a href="delete_car.php">Delete Cars</a></li>
                            <li><a href="Update_car.php">Update Cars</a></li>
                            <li><a href="delete_comment.php"> Delete Comment</a></li>

                        </ul>
                    </li>
                    <li class="dropdown">
                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">More <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="team.php">Team</a></li>
                            <li><a href="comment.php">Comment</a></li>
                        </ul>
                    </li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="login.php">Loguot</a></li>
                </ul>
            </div>
        </div>
    </section>


<section>
    <div class="container">
        <div class="text-center">
            <h1>Car Listing</h1>
            <br>
            <p class="lead">You can see the available cars and their prices and you can order through the page (Contact Us)</p>
        </div>
    </div>
</section>

<section class="section-background">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-xs-12">
                <div class="form">
                   
                </div>
            </div>

            <div class="col-lg-9 col-xs-12">
                <div class="row">
                    <?php
                    $sql = "SELECT * FROM cars";
                    $result = $conn->query($sql);
                    

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo '
                            <div class="col-lg-6 col-md-4 col-sm-6">
                                <div class="courses-thumb courses-thumb-secondary">
                                    <div class="courses-top">
                                        <div class="courses-image">
                                            <img src="images/' . $row['image'] . '" class="img-responsive" alt="">
                                        </div>
                                        <div class="courses-date">
                                            <span title="Mileage"><i class="fa fa-dashboard"></i> ' . $row['mileage'] . 'km</span>
                                            <span title="Engine Size"><i class="fa fa-cube"></i> ' . $row['engine_size'] . 'cc</span>
                                            <span title="Gearbox"><i class="fa fa-cog"></i> ' . $row['gearbox'] . '</span>
                                        </div>
                                    </div>

                                    <div class="courses-detail">
                                        <h3><a href="car-details.php?id=' . $row['id'] . '">' . $row['model'] . '</a></h3>
                                        <p class="lead"><small><del>$' . ($row['price'] + 200) . '</del></small> <strong>$' . $row['price'] . '</strong></p>
                                        <p>' . $row['description'] . '</p>
                                    </div>

                                    <div class="courses-info">
                                        <a href="car-details.php?id=' . $row['id'] . '" class="section-btn btn btn-primary btn-block">View More</a>
                                     
                                        </div>
                                </div>
                            </div>';
                        }
                    } else {
                        echo '<p>No cars found in the database.</p>';
                    }

                    $conn->close();
                    ?>
                </div>
               
            </div>
        </div>
    </div>
</section>

<?php include "inc/footer.php"; ?>
