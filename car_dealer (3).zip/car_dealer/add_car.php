<?php
include "inc/header.php"; 
include "db.php";

// form add car
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $model = $_POST['model'];
    $type = $_POST['type'];
    $mileage = $_POST['mileage'];
    $engine_size = $_POST['engine_size'];
    $gearbox = $_POST['gearbox'];
    $color = $_POST['color'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $image = $_FILES['image']['name'];
    $target = "images/".basename($image);

    $sql = "INSERT INTO cars (type, model, mileage, engine_size, gearbox, color, price, description, image) 
            VALUES ('$type', '$model', '$mileage', '$engine_size', '$gearbox', '$color', '$price', '$description', '$image')";
    
    if ($conn->query($sql) === TRUE) {
        if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            echo "New car added successfully";
        } else {
            echo "Error uploading image";
        }
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

//  display cars
$sql = "SELECT * FROM cars";
$result = $conn->query($sql);

if ($result === false) {
    echo "Error: " . $conn->error;
    exit;
}
?>

<!-- PRE LOADER -->
<section class="preloader">
    <div class="spinner">
        <span class="spinner-rotate"></span>
    </div>
</section>

<!-- MENU -->
<section class="navbar custom-navbar navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon icon-bar"></span>
                <span class="icon icon-bar"></span>
                <span class="icon icon-bar"></span>
            </button>
            <a href="#" class="navbar-brand">Car Dealer Website</a>
        </div>

        <!-- MENU LINKS -->
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-nav-first">
                <li><a href="home.php">Home</a></li>
                <li><a href="cars.php">Cars</a></li>
                <li><a href="about-us.php">About Us</a></li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Admin<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="add_car.php">Add Cars</a></li>
                        <li><a href="delete_car.php">Delete Cars</a></li>
                        <li><a href="update_car.php">Update Cars</a></li>
                        <li><a href="delete_comment.php">Delete Comment</a></li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">More <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="team.php">Team</a></li>
                        <li><a href="comment.php">Comment</a></li>
                    </ul>
                </li>
                <li><a href="contact.php">Contact Us</a></li>
                <li><a href="login.php">Loguot</a></li>
                
            </ul>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="text-center">
            <h1>Add Car</h1>
            <br>
            <p class="lead">You can add cars from this page</p>
        </div>
    </div>
</section>

<section class="section-background">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-xs-12">
                <form id="contact-form" role="form" action="add_car.php" method="post" enctype="multipart/form-data">
                    <h2>Adding Cars:</h2>
                    <div class="col-md-12 col-sm-12">
                        <label>Type:</label>
                        <input type="text" class="form-control" placeholder="type" name="type" required>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <label>Model:</label>
                        <input type="text" class="form-control" placeholder="model" name="model" required>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <label>Mileage:</label>
                        <input type="text" class="form-control" placeholder="mileage" name="mileage" required>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <label>Engine Size:</label>
                        <input type="number" class="form-control" placeholder="engine_size" name="engine_size" required>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <label>Gearbox:</label>
                        <input type="text" class="form-control" placeholder="gearbox" name="gearbox" required>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <label>Color:</label>
                        <input type="text" class="form-control" placeholder="color" name="color" required>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <label>Price:</label>
                        <input type="text" class="form-control" placeholder="price" name="price" required>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <label>Description:</label>
                        <textarea class="form-control" rows="6" placeholder="description" name="description" required></textarea>
                    </div>
                    <div class="col-md-12 col-sm-12">
                        <label>Image:</label>
                        <input type="file" class="form-control" placeholder="image" name="image" required>
                    </div>
                    <div class="col-md-4 col-sm-12">
                    <input type="submit" class="form-control" value="Add" style="background-color: #29ca8e; border-color: #29ca8e; color: white;">

                    </div>
                </form>
            </div>


            <!-- display car -->
            <div class="col-lg-8 col-xs-12">
                <br>
                <h2 class="text-center">Cars List:</h2>
                <?php
                if ($result->num_rows > 0) {
                    echo '<table class="table table-striped">';
                    echo '<thead><tr>';
                    echo '<th>ID</th>';
                    echo '<th>Type</th>';
                    echo '<th>Model</th>';
                    echo '<th>Mileage</th>';
                    echo '<th>Engine Size</th>';
                    echo '<th>Gearbox</th>';
                    echo '<th>Color</th>';
                    echo '<th>Price</th>';
                    echo '<th>Description</th>';
                    echo '<th>Image</th>';
                    echo '</tr></thead>';
                    echo '<tbody>';
                    while($row = $result->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>' . $row['id'] . '</td>';
                        echo '<td>' . $row['type'] . '</td>';
                        echo '<td>' . $row['model'] . '</td>';
                        echo '<td>' . $row['mileage'] . '</td>';
                        echo '<td>' . $row['engine_size'] . '</td>';
                        echo '<td>' . $row['gearbox'] . '</td>';
                        echo '<td>' . $row['color'] . '</td>';
                        echo '<td>' . $row['price'] . '</td>';
                        echo '<td>' . $row['description'] . '</td>';
                        echo '<td><img src="images/' . $row['image'] . '" alt="Car Image" width="100"></td>';
                        echo '</tr>';
                    }
                    echo '</tbody></table>';
                } else {
                    echo '<p>No cars found</p>';
                }
                $conn->close();
                ?>
            </div>
        </div>
    </div>
    
</section>

<?php include "inc/footer.php"; ?>
