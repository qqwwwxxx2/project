<?php include "inc/header.php" ?>

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="#" class="navbar-brand ">Car Dealer Website </a>
               </div>

           <!-- MENU LINKS -->
           <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-nav-first">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="cars.php">Cars</a></li>
                    <li class="active"><a href="admin.php">Admin</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Admin<span class="caret"></span></a>
                        
                        <ul class="dropdown-menu">
                            <li><a href="add_car.php">Add_Cars</a></li>
                            <li><a href="Update_car.php">Update Cars</a></li>
                            <li><a href="delete_car.php">Delete Cars</a></li>
                            <li><a href="comment.php">comment</a></li>
                        </ul>
                    </li>

                    <li class="dropdown">
                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">More <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="team.php">Team</a></li>
                            <li><a href="testimonials.php">Testimonials</a></li>
                            <li><a href="comment.php">comment</a></li>
                        </ul>
                    </li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </div>
        </div>
    </section>

     <section>
          <div class="container">
               <div class="text-center">
                    <h1>Admin </h1>

                    <br>

                    <p class="lead">adding and deleting and update </p>
               </div>
          </div>
     </section>

           <div class="section-btn">
                    <a href="add_car.php" class="section-btn btn btn-primary btn-block" >Add Car</a>
          </div>
          <br>
          <div class="section-btn">
                        <a href="delete_car.php" class="section-btn btn btn-primary btn-block" >Delete Car</a>
        </div>
      <br>
      
      <div class="section-btn">
                    <a href="Update_car.php" class="section-btn btn btn-primary btn-block" >Update Car</a>
          </div>
      
      <br><br>
     <?php include "inc/footer.php" ?>
