<?php include "inc/header.php" ?>

     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="#" class="navbar-brand">Car Dealer Website</a>
               </div>

        <!-- MENU LINKS -->
    <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-nav-first">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="cars.php">Cars</a></li>
                    <li class="active"><a href="about-us.php">About Us</a></li>
                    
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Admin<span class="caret"></span></a>
                        
                        <ul class="dropdown-menu">
                            <li><a href="add_car.php">Add Cars</a></li>
                            <li><a href="delete_car.php">Delete Cars</a></li>
                            <li><a href="Update_car.php">Update Cars</a></li>
                            <li><a href="delete_comment.php"> Delete Comment</a></li>

                        </ul>
                    </li>
                    <li class="dropdown">
                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">More <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="team.php">Team</a></li>
                            <li><a href="comment.php">Comment</a></li>
                        </ul>
                    </li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="login.php">Loguot</a></li>
                </ul>
            </div>
        </div>
    </section>

     <section>
          <div class="container">
               <div class="text-center">
                    <h1>About Us</h1>

                    <br>
                    <p class="lead">Feel free to modify this to better suit your specific dealership's values and offerings.</p>
               </div>
          </div>
     </section>


     <section class="section-background">
          <div class="container">
               <div class="row">
                    <div class="col-md-12 col-sm-12">
                         <div class="text-center">
                              <h2>Welcome to our Car Dealer Website!</h2>

                              <br>

                              <p class="lead">We are dedicated to providing you with the best car buying experience possible. Our team of experienced professionals is committed to helping you find the perfect vehicle that suits your needs and budget.

At our dealership, we offer a wide range of new and pre-owned vehicles from various makes and models. Whether you are looking for a family car, a luxury sedan, or a reliable SUV, we have something for everyone. Our knowledgeable staff is always on hand to answer your questions and guide you through the buying process.

We pride ourselves on our exceptional customer service and strive to create a hassle-free, enjoyable car buying experience. Our goal is to build long-term relationships with our customers by providing quality vehicles and outstanding support.

Thank you for choosing our dealership. We look forward to serving you and helping you drive away in the car of your dreams.</p>
                         </div>
                    </div>
               </div>
          </div>
     </section>

     <?php include "inc/footer.php" ?>
