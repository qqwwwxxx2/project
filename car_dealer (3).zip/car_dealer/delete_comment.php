<?php include "inc/header.php" ?>

<?php

include "db.php";

$message = '';
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);
    $sql = "DELETE FROM comments WHERE id = $delete_id";

    if ($conn->query($sql) === TRUE) {
        $message = "Comment deleted successfully";
    } else {
        $message = "Error: " . $sql . "<br>" . $conn->error;
    }
}


$sql = "SELECT * FROM comments ORDER BY id DESC";
$result = $conn->query($sql);
?>

 <!-- PRE LOADER -->
 <section class="preloader">
          <div class="spinner">
               <span class="spinner-rotate"></span>
          </div>
     </section>

     <!-- MENU -->
<section class="navbar custom-navbar navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon icon-bar"></span>
                <span class="icon icon-bar"></span>
                <span class="icon icon-bar"></span>
            </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="#" class="navbar-brand">Car Dealer Website</a>
               </div>
     
      <!-- MENU LINKS -->
    <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-nav-first">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="cars.php">Cars</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Admin<span class="caret"></span></a>
                        
                        <ul class="dropdown-menu">
                            <li><a href="add_car.php">Add Cars</a></li>
                            <li><a href="delete_car.php">Delete Cars</a></li>
                            <li><a href="Update_car.php">Update Cars</a></li>
                            <li><a href="delete_comment.php"> Delete Comment</a></li>

                        </ul>
                    </li>
                    <li class="dropdown">
                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">More <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="team.php">Team</a></li>
                            <li><a href="comment.php">Comment</a></li>
                        </ul>
                    </li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="login.php">Loguot</a></li>
                </ul>
            </div>
        </div>
    </section>

<section>
    <div class="container">
        <div class="text-center">
            <h1>Delete Comments</h1>
            <br>
            <?php if ($message) { echo '<div class="alert alert-info">' . $message . '</div>'; } ?>
        </div>
    </div>
</section>

<!-- disply here -->
<section>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <h2>Comments</h2>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<div class='comment-box'>";
                        echo "<h4>" . htmlspecialchars($row['name']) . "</h4>";
                        echo "<p>" . htmlspecialchars($row['comment']) . "</p>";
                        echo "<a href='delete_comment.php?delete_id=" . $row['id'] . "' class='btn btn-danger'>Delete</a>";
                        echo "</div><hr>";
                    }
                } else {
                    echo "No comments yet.";
                }
                $conn->close();
                ?>
            </div>
        </div>
    </div>
</section>

<?php include "inc/footer.php" ?>
