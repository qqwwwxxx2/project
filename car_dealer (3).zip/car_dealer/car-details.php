<?php
include "inc/header.php";
include "db.php"; 

// Check if the car ID is provided in the query string
if(isset($_GET['id'])) {
    // Fetch the car ID from the query string
    $car_id = $_GET['id'];

    // Prepare and execute the SQL query to retrieve car details based on the ID
    $sql = "SELECT * FROM cars WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $car_id);
    $stmt->execute();

    // Get the result of the query
    $result = $stmt->get_result();

    // Check if a car with the provided ID exists
    if ($result->num_rows > 0) {
        // Fetch the car details
        $car = $result->fetch_assoc();
?>
    <!-- PRE LOADER -->
    <section class="preloader">
        <div class="spinner">
            <span class="spinner-rotate"></span>
        </div>
    </section>

    <!-- MENU -->
    <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon icon-bar"></span>
                    <span class="icon icon-bar"></span>
                    <span class="icon icon-bar"></span>
                </button>

                <!-- lOGO TEXT HERE -->
                <a href="#" class="navbar-brand">Car Dealer Website</a>
            </div>
<!-- MENU LINKS -->
<div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-nav-first">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="cars.php">Cars</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Admin<span class="caret"></span></a>
                        
                        <ul class="dropdown-menu">
                            <li><a href="add_car.php">Add Cars</a></li>
                            <li><a href="delete_car.php">Delete Cars</a></li>
                            <li><a href="Update_car.php">Update Cars</a></li>
                            <li><a href="delete_comment.php"> Delete Comment</a></li>

                        </ul>
                    </li>
                    <li class="dropdown">
                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">More <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="team.php">Team</a></li>
                            <li><a href="comment.php">Comment</a></li>
                        </ul>
                    </li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="login.php">Loguot</a></li>
                </ul>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-xs-12">
                    <div>
                        <img src="images/<?php echo $car['image']; ?>" alt="" class="img-responsive wc-image">
                    </div>

                    <br>

                    <div class="row">
                        <!-- Add more images if needed -->
                    </div>
                </div>

                <div class="col-md-6 col-xs-12">
                    <form action="#" method="post" class="form">
                        <h2><?php echo $car['model']; ?></h2>
                        <p class="lead"><?php echo $car['description']; ?></p>
                        <p class="lead"> <strong class="text-primary">$<?php echo $car['price']; ?></strong></p>

                        <div class="row">
                            <div class="col-md-4 col-sm-6">
                                <p>
                                    <span>Type</span>
                                    <br>
                                    <strong><?php echo $car['type']; ?></strong>
                                </p>
                            </div>

                            <div class="col-md-4 col-sm-6">
                                <p>
                                    <span> Model</span>
                                    <br>
                                    <strong><?php echo $car['model']; ?> </strong>
                                </p>
                            </div>

                            <div class="col-md-4 col-sm-6">
                                <p>
                                    <span> Mileage</span>
                                    <br>
                                    <strong><?php echo $car['mileage']; ?> km</strong>
                                </p>
                            </div>

                            <div class="col-md-4 col-sm-6">
                                <p>
                                    <span>Engine size</span>
                                    <br>
                                    <strong><?php echo $car['engine_size']; ?> cc</strong>
                                </p>
                            </div>

                            <div class="col-md-4 col-sm-6">
                                <p>
                                    <span>Gearbox</span>
                                    <br>
                                    <strong><?php echo $car['gearbox']; ?></strong>
                                </p>
                            </div>

                            <div class="col-md-4 col-sm-6">
                                <p>
                                    <span>Color</span>
                                    <br>
                                    <strong><?php echo $car['color']; ?></strong>
                                </p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <?php
    } else {
        // If no car found with the specified ID
        echo '<p>No car found with the specified ID.</p>';
    }

    // Close the prepared statement
    $stmt->close();
} else {
    // If no car ID specified in the query string
    echo '<p>No car ID specified.</p>';
}

include "inc/footer.php";
?>
