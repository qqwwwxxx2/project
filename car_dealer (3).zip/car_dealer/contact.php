<?php include "inc/header.php" ?>
     <!-- PRE LOADER -->
     <section class="preloader">
          <div class="spinner">

               <span class="spinner-rotate"></span>
               
          </div>
     </section>


     <!-- MENU -->
     <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
          <div class="container">

               <div class="navbar-header">
                    <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                         <span class="icon icon-bar"></span>
                    </button>

                    <!-- lOGO TEXT HERE -->
                    <a href="#" class="navbar-brand">Car Dealer Website</a>
               </div>

          
        <!-- MENU LINKS -->
    <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-nav-first">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="cars.php">Cars</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Admin<span class="caret"></span></a>
                        
                        <ul class="dropdown-menu">
                            <li><a href="add_car.php">Add Cars</a></li>
                            <li><a href="delete_car.php">Delete Cars</a></li>
                            <li><a href="Update_car.php">Update Cars</a></li>
                            <li><a href="delete_comment.php"> Delete Comment</a></li>

                        </ul>
                    </li>
                    <li class="dropdown">
                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">More <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="team.php">Team</a></li>
                            <li><a href="comment.php">Comment</a></li>
                        </ul>
                    </li>
                    <li class="active"><a href="contact.php">Contact Us</a></li>
                    <li><a href="login.php">Loguot</a></li>
                </ul>
            </div>
        </div>
    </section>

     <section>
          <div class="container">
               <div class="text-center">
                    <h1>Contact Us</h1>

                    <br>

                    <p class="lead">We will be happy to communicate with you</p>
               </div>
          </div>
     </section>


     <!-- CONTACT -->
     <section id="contact">
          <div class="container">
               <div class="row">

                    <div class="col-md-6 col-sm-12">
                         <form id="contact-form" role="form" action="" method="post">
                              <div class="col-md-12 col-sm-12">
                                   <input type="text" class="form-control" placeholder="Enter full name" name="name" required>
                    
                                   <input type="email" class="form-control" placeholder="Enter email address" name="email" required>

                                   <textarea class="form-control" rows="6" placeholder="Tell us about your message" name="message" required></textarea>
                              </div>

                              <div class="col-md-4 col-sm-12">
                                   <input type="submit" class="form-control" name="send message" value="Send Message">
                              </div>

                         </form>
                    </div>

                    <div class="col-md-6 col-sm-12">
                         <div class="contact-image">
                              <img src="images/contact-1-600x400.jpg" class="img-responsive" alt="">
                         </div>
                    </div>

               </div>
          </div>
     </section>       

     <?php include "inc/footer.php" ?>