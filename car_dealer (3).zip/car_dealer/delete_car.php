<?php
include "db.php";
include "inc/header.php";

$message = ""; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $car_id = $_POST['car_id'];

  
    if (filter_var($car_id, FILTER_VALIDATE_INT)) {
        $sql = "DELETE FROM cars WHERE id = $car_id";

        if ($conn->query($sql) === TRUE) {
            $message = "Car deleted successfully";
        } else {
            $message = "Error: " . $sql . "<br>" . $conn->error;
        }
    } else {
        $message = "Invalid car ID";
    }

    
}
    //  display cars
$sql = "SELECT * FROM cars";
$result = $conn->query($sql);

if ($result === false) {
    echo "Error: " . $conn->error;
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Car</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- PRE LOADER -->
    <section class="preloader">
        <div class="spinner">
            <span class="spinner-rotate"></span>
        </div>
    </section>

    <!-- MENU -->
    <section class="navbar custom-navbar navbar-fixed-top" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon icon-bar"></span>
                    <span class="icon icon-bar"></span>
                    <span class="icon icon-bar"></span>
                </button>

                <!-- lOGO TEXT HERE -->
                <a href="#" class="navbar-brand">Car Dealer Website</a>
            </div>

               
        <!-- MENU LINKS -->
    <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-nav-first">
                    <li><a href="home.php">Home</a></li>
                    <li><a href="cars.php">Cars</a></li>
                    <li><a href="about-us.php">About Us</a></li>
                    
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Admin<span class="caret"></span></a>
                        
                        <ul class="dropdown-menu">
                            <li><a href="add_car.php">Add Cars</a></li>
                            <li><a href="delete_car.php">Delete Cars</a></li>
                            <li><a href="Update_car.php">Update Cars</a></li>
                            <li><a href="delete_comment.php"> Delete Comment</a></li>

                        </ul>
                    </li>
                    <li class="dropdown">
                     <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">More <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="team.php">Team</a></li>
                            <li><a href="comment.php">Comment</a></li>
                        </ul>
                    </li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="login.php">Loguot</a></li>
                </ul>
            </div>
        </div>
    </section>


    <section>
        <div class="container">
            <div class="text-center">
                <h1>Delete Car</h1>
                <br>
                <p class="lead">Deleting a car by its ID</p>
                <?php
                if ($message != "") {
                    echo "<div class='alert alert-info'>$message</div>";
                }
                ?>
            </div>
        </div>
    </section>

    <section class="section-background">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-xs-12">
                    <form id="contact-form" role="form" action="delete_car.php" method="post">
                     <h2>Delete Car:</h2>
                      <div class="col-md-12 col-sm-12">
                        <label>Car ID:</label>
                      <input type="number" class="form-control" placeholder="Enter Car ID" name="car_id" required>
                       </div>
                     <div class="col-md-4 col-sm-12">
                      <input type="submit" class="form-control" value="Delete"  style="background-color: red; border-color: red; color: white;">
                     </div>
                    </form>
                </div>
                <div class="col-lg-8 col-xs-12">
                <br>
                <h2 class="text-center">Cars List:</h2>
                <?php
                if ($result->num_rows > 0) {
                    echo '<table class="table table-striped">';
                    echo '<thead><tr>';
                    echo '<th>ID</th>';
                    echo '<th>Type</th>';
                    echo '<th>Model</th>';
                    echo '<th>Mileage</th>';
                    echo '<th>Engine Size</th>';
                    echo '<th>Gearbox</th>';
                    echo '<th>Color</th>';
                    echo '<th>Price</th>';
                    echo '<th>Description</th>';
                    echo '<th>Image</th>';
                    echo '</tr></thead>';
                    echo '<tbody>';
         while($row = $result->fetch_assoc()) {
                        echo '<tr>';
                        echo '<td>' . $row['id'] . '</td>';
                        echo '<td>' . $row['type'] . '</td>';
                        echo '<td>' . $row['model'] . '</td>';
                        echo '<td>' . $row['mileage'] . '</td>';
                        echo '<td>' . $row['engine_size'] . '</td>';
                        echo '<td>' . $row['gearbox'] . '</td>';
                        echo '<td>' . $row['color'] . '</td>';
                        echo '<td>' . $row['price'] . '</td>';
                        echo '<td>' . $row['description'] . '</td>';
                        echo '<td><img src="images/' . $row['image'] . '" alt="Car Image" width="100"></td>';
                        echo '</tr>';
               }
          echo '</tbody></table>';
      } else {
        echo '<p>No cars found</p>';
     }
             
     ?>
        
    </div> 
    </div>
    </div>
    
</section>
 
    
    <?php include "inc/footer.php"; ?>
</body>
</html>
